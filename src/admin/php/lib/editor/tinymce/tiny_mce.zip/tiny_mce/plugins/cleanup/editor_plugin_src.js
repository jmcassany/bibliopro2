/**
 * $RCSfile: editor_plugin_src.js,v $
 * $Revision: 1.10 $
 * $Date: 2006/02/10 16:29:38 $
 *
 * Experimental plugin for new Cleanup routine, this logic will be moved into the core ones it's stable enougth.
 *
 * @author Moxiecode
 * @copyright Copyright � 2004-2006, Moxiecode Systems AB, All rights reserved.
 */

/* Dummy file since cleanup is now moved to core */
